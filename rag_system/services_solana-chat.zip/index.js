const functions = require('@google-cloud/functions-framework');
const { VertexAI } = require('@google-cloud/vertexai');

functions.http('chatHandler', async (req, res) => {
  if (req.method !== 'POST') {
    res.status(405).send({ error: 'Method not allowed. Please use POST.' });
    return;
  }

  const question = req.body.question;
  if (!question) {
    res.status(400).send({ error: 'Question not provided in request body.' });
    return;
  }

  const vertex_ai = new VertexAI({ project: 'hackathum24mun-36', location: 'us-central1' });
  const model = 'gemini-1.5-flash-002';

  const textsi_1 = {
    text: `You are a coding assistant for a Solana developer. You have access to the full Solana documentation via the provided grounding source. Answer each question with as much detail as possible. Also, provide code examples to help in your explanation.`,
  };

  // Instantiate the model
  const generativeModel = vertex_ai.preview.getGenerativeModel({
    model: model,
    generationConfig: {
      maxOutputTokens: 1024,
      temperature: 0.2,
      topP: 0.8,
    },
    safetySettings: [
      { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'OFF' },
      { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'OFF' },
      { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'OFF' },
      { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'OFF' },
    ],
    tools: [
      {
        retrieval: {
          vertexAiSearch: {
            datastore: 'projects/hackathum24mun-36/locations/us/collections/default_collection/dataStores/test-datastore_1732355379979',
          },
        },
      },
    ],
    systemInstruction: {
      parts: [textsi_1],
    },
  });

  const chat = generativeModel.startChat({});

  async function sendMessage(message) {
    const streamResult = await chat.sendMessageStream(message);
    const responseContent = (await streamResult.response).candidates[0].content;
    return responseContent;
  }

  async function generateContent(question) {
    const answer = await sendMessage([{ text: question }]);
    return answer;
  }

  try {
    const answer = await generateContent(question);
    res.status(200).json({ answer: answer });
  } catch (error) {
    res.status(500).send({ error: 'An error occurred while processing the request.' });
  }
});
